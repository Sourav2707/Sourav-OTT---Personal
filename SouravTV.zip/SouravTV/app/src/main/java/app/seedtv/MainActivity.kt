package app.seedtv

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.os.Message
import android.os.SystemClock
import android.view.*
import android.webkit.*
import android.widget.FrameLayout
import java.io.ByteArrayInputStream

// ---- EDIT THESE ----
private const val HOME = "https://seedmivo.st"
// Pages may only navigate within these hosts. Anything else (redirects) is blocked.
private val ALLOWED = listOf("seedmivo.st")
// Sub-requests to these hosts are dropped (starter list; add more as you spot ads).
private val BLOCKED = listOf(
    "doubleclick.net", "googlesyndication.com", "adservice.google.com", "popads.net",
    "popcash.net", "propellerads.com", "onclickads.net", "adsterra.com", "exoclick.com",
    "juicyads.com", "trafficjunky.com", "adnxs.com", "taboola.com", "outbrain.com", "histats.com"
)
// --------------------

private fun hostIn(host: String?, list: List<String>) =
    host != null && list.any { host == it || host.endsWith(".$it") }

class CursorView(c: Context) : View(c) {
    var cx = 0f
    var cy = 0f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 4f
    }
    override fun onDraw(canvas: Canvas) {
        val p = Path().apply {
            moveTo(cx, cy); lineTo(cx, cy + 42f); lineTo(cx + 12f, cy + 32f)
            lineTo(cx + 22f, cy + 52f); lineTo(cx + 30f, cy + 48f)
            lineTo(cx + 20f, cy + 29f); lineTo(cx + 34f, cy + 28f); close()
        }
        canvas.drawPath(p, fill)
        canvas.drawPath(p, edge)
    }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var cursor: CursorView
    private lateinit var root: FrameLayout
    private var cursorOn = true
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this)
        web = WebView(this)
        cursor = CursorView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(cursor, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        root.post { cursor.cx = root.width / 2f; cursor.cy = root.height / 2f; cursor.invalidate() }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            useWideViewPort = true
            loadWithOverviewMode = true
            userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean =
                r.isForMainFrame && !hostIn(r.url.host, ALLOWED)

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                if (hostIn(r.url.host, BLOCKED))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null
        }
        web.webChromeClient = object : WebChromeClient() {
            // Popups / new tabs are always refused.
            override fun onCreateWindow(v: WebView, d: Boolean, u: Boolean, m: Message?) = false

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                customView = view; customCb = cb
                root.addView(view, FrameLayout.LayoutParams(-1, -1))
                cursor.bringToFront()
            }
            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null
                customCb?.onCustomViewHidden()
                customCb = null
            }
        }
        web.loadUrl(HOME)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    private fun click() {
        val target: View = customView ?: web
        val t = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, cursor.cx, cursor.cy, 0)
        target.dispatchTouchEvent(down); down.recycle()
        target.postDelayed({
            val t2 = SystemClock.uptimeMillis()
            val up = MotionEvent.obtain(t2, t2, MotionEvent.ACTION_UP, cursor.cx, cursor.cy, 0)
            target.dispatchTouchEvent(up); up.recycle()
        }, 60)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val k = e.keyCode
        // Toggle cursor: yellow button, Menu, or Subtitle
        if (k == KeyEvent.KEYCODE_PROG_YELLOW || k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_CAPTIONS) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
                cursorOn = !cursorOn
                cursor.visibility = if (cursorOn) View.VISIBLE else View.INVISIBLE
            }
            return true
        }
        if (!cursorOn) return super.dispatchKeyEvent(e)

        val step = (10 + minOf(e.repeatCount, 15) * 2) * resources.displayMetrics.density
        when (k) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (e.action == KeyEvent.ACTION_DOWN) {
                    val w = root.width.toFloat(); val h = root.height.toFloat()
                    when (k) {
                        KeyEvent.KEYCODE_DPAD_UP -> cursor.cy -= step
                        KeyEvent.KEYCODE_DPAD_DOWN -> cursor.cy += step
                        KeyEvent.KEYCODE_DPAD_LEFT -> cursor.cx -= step
                        else -> cursor.cx += step
                    }
                    cursor.cx = cursor.cx.coerceIn(0f, w - 2f)
                    cursor.cy = cursor.cy.coerceIn(0f, h - 2f)
                    // Cursor pushed against the top/bottom edge scrolls the page
                    if (cursor.cy <= 2f && k == KeyEvent.KEYCODE_DPAD_UP) web.scrollBy(0, (-step * 3).toInt())
                    if (cursor.cy >= h - 4f && k == KeyEvent.KEYCODE_DPAD_DOWN) web.scrollBy(0, (step * 3).toInt())
                    cursor.invalidate()
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) click()
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
