package app.seedtv

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.os.SystemClock
import android.view.*
import android.webkit.*
import android.widget.FrameLayout
import java.io.ByteArrayInputStream

// ---------------- EDIT THESE ----------------
private const val HOME = "https://seedmivo.st"

// The ONLY hosts the page itself may navigate to. Every redirect elsewhere is aborted.
private val ALLOWED = listOf("seedmivo.st")

// STRICT = false: block only the ad hosts below, allow other sub-resources (video players etc.).
// STRICT = true : sub-resources may load ONLY from ALLOWED + ALLOWED_EXTRA (safest, but you must
//                 add the video player's host to ALLOWED_EXTRA or playback will break).
private const val STRICT = false
private val ALLOWED_EXTRA = listOf("image.tmdb.org")

private val BLOCKED = listOf(
    "doubleclick.net", "googlesyndication.com", "adservice.google.com", "popads.net",
    "popcash.net", "propellerads.com", "onclickads.net", "adsterra.com", "exoclick.com",
    "juicyads.com", "trafficjunky.com", "adnxs.com", "taboola.com", "outbrain.com", "histats.com",
    "adcash.com", "clickadu.com", "hilltopads.net", "mgid.com", "revcontent.com", "zedo.com",
    "yllix.com", "pubmatic.com", "rubiconproject.com", "openx.net", "criteo.com",
    "amazon-adsystem.com", "googletagservices.com", "admaven.com", "a-ads.com", "monetag.com"
)
// --------------------------------------------

// Runs inside every page: no popups, no off-site links/forms, hides ad elements and ad overlays.
private const val CLEAN_JS = """
(function(){
  if (window.__stv) return; window.__stv = 1;
  window.open = function(){ return null; };
  var OK = /(^|\.)seedmivo\.st${'$'}/;
  var AD = /^(ad|ads|adv|advert|advertisement|adsbygoogle|ad-banner|banner-ad|ad-slot|ad-container|ad-wrapper|sponsor|sponsored|popunder|popup-ad|pop-ad)${'$'}/i;
  var SRC = /(^|[\/.\-_])(ads?|adserver|banner|popunder|sponsor)([\/.\-_?]|${'$'})/i;
  function host(u){ try { return new URL(u, location.href).hostname; } catch(e){ return ''; } }
  function ext(u){ var h = host(u); return !!h && !OK.test(h); }
  function hide(el){ el.style.setProperty('display','none','important'); }

  var ac = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){ if (this.href && ext(this.href)) return; return ac.apply(this, arguments); };
  var fs = HTMLFormElement.prototype.submit;
  HTMLFormElement.prototype.submit = function(){ if (this.action && ext(this.action)) return; return fs.apply(this, arguments); };
  document.addEventListener('submit', function(e){
    if (e.target && e.target.action && ext(e.target.action)) { e.preventDefault(); e.stopPropagation(); }
  }, true);
  document.addEventListener('click', function(e){
    var a = e.target && e.target.closest ? e.target.closest('a') : null;
    if (!a || !a.href || /^javascript:/i.test(a.href)) return;
    if (!/^https:/i.test(a.href) || ext(a.href)) { e.preventDefault(); e.stopPropagation(); return; }
    if (a.target === '_blank') a.target = '_self';
  }, true);

  function sweep(){
    var all = document.querySelectorAll('div,section,aside,ins,iframe,a,img');
    for (var i=0;i<all.length;i++){
      var el = all[i], bad = false;
      var cn = (typeof el.className === 'string') ? el.className : '';
      var toks = (cn + ' ' + (el.id||'')).split(/\s+/);
      for (var t=0;t<toks.length;t++){ if (toks[t] && AD.test(toks[t])) { bad = true; break; } }
      if (!bad && el.tagName === 'IFRAME' && el.src && ext(el.src) && SRC.test(el.src)) bad = true;
      if (!bad && (el.tagName === 'DIV' || el.tagName === 'IFRAME')) {
        var cs = getComputedStyle(el);
        if (cs.position === 'fixed' && parseInt(cs.zIndex||'0',10) >= 1000) {
          var r = el.getBoundingClientRect();
          var big = r.width*r.height > innerWidth*innerHeight*0.25;
          var off = el.tagName === 'IFRAME' ? ext(el.src) :
                    !!el.querySelector('a[href^="http"]:not([href*="seedmivo.st"]),iframe');
          if (big && off && !el.querySelector('video')) bad = true;
        }
      }
      if (bad) hide(el);
    }
  }
  var pending = false;
  new MutationObserver(function(){
    if (pending) return; pending = true;
    setTimeout(function(){ pending = false; sweep(); }, 400);
  }).observe(document.documentElement, {childList:true, subtree:true});
  sweep();
})();
"""

private fun hostIn(host: String?, list: List<String>) =
    host != null && list.any { host == it || host.endsWith(".$it") }

private fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

class CursorView(c: Context) : View(c) {
    var cx = 0f
    var cy = 0f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 4f
    }
    override fun onDraw(canvas: Canvas) {
        val p = Path().apply {
            moveTo(cx, cy); lineTo(cx, cy + 42f); lineTo(cx + 12f, cy + 32f)
            lineTo(cx + 22f, cy + 52f); lineTo(cx + 30f, cy + 48f)
            lineTo(cx + 20f, cy + 29f); lineTo(cx + 34f, cy + 28f); close()
        }
        canvas.drawPath(p, fill)
        canvas.drawPath(p, edge)
    }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var cursor: CursorView
    private lateinit var root: FrameLayout
    private var cursorOn = true
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WebView.setWebContentsDebuggingEnabled(false)
        root = FrameLayout(this)
        web = WebView(this)
        cursor = CursorView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(cursor, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        root.post { cursor.cx = root.width / 2f; cursor.cy = root.height / 2f; cursor.invalidate() }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            useWideViewPort = true
            loadWithOverviewMode = true
            // Lock the WebView away from the TV's files and other apps' data
            allowFileAccess = false
            allowContentAccess = false
            setGeolocationEnabled(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        // Never download anything (blocks drive-by APK / file downloads)
        web.setDownloadListener { _, _, _, _, _ -> }

        web.webViewClient = object : WebViewClient() {
            // Abort every redirect / link that leaves the allowed site, and every non-https scheme
            // (intent:, market:, magnet:, javascript: navigations, ...).
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url; val s = u.scheme
                if (r.isForMainFrame) return !(s == "https" && hostIn(u.host, ALLOWED))
                return s != "https" && s != "about" && s != "data" && s != "blob"
            }

            override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) {
                v.evaluateJavascript(CLEAN_JS, null)
            }
            override fun onPageFinished(v: WebView, url: String?) {
                v.evaluateJavascript(CLEAN_JS, null)
            }

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val s = r.url.scheme
                val h = r.url.host
                if (s == "http") return empty()                                   // https only
                if (s != "https" && s != "data" && s != "blob" && s != "about") return empty()
                if (hostIn(h, BLOCKED)) return empty()
                if (STRICT && s == "https" && !hostIn(h, ALLOWED + ALLOWED_EXTRA)) return empty()
                return null
            }

            // Bad / fake certificates: always refuse, never "proceed anyway"
            override fun onReceivedSslError(v: WebView, h: SslErrorHandler, e: android.net.http.SslError) {
                h.cancel()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            // Popups / new tabs: refused
            override fun onCreateWindow(v: WebView, d: Boolean, u: Boolean, m: Message?) = false

            // JS alert/confirm/prompt popups: dismissed silently
            override fun onJsAlert(v: WebView, url: String?, msg: String?, r: JsResult): Boolean { r.cancel(); return true }
            override fun onJsConfirm(v: WebView, url: String?, msg: String?, r: JsResult): Boolean { r.cancel(); return true }
            override fun onJsPrompt(v: WebView, url: String?, msg: String?, def: String?, r: JsPromptResult): Boolean { r.cancel(); return true }
            override fun onJsBeforeUnload(v: WebView, url: String?, msg: String?, r: JsResult): Boolean { r.confirm(); return true }

            // No camera / microphone / location for the site (DRM playback id is the one exception)
            override fun onPermissionRequest(r: PermissionRequest) {
                val ok = r.resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }.toTypedArray()
                if (ok.isEmpty()) r.deny() else r.grant(ok)
            }
            override fun onGeolocationPermissionsShowPrompt(o: String, cb: GeolocationPermissions.Callback) {
                cb.invoke(o, false, false)
            }

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                customView = view; customCb = cb
                root.addView(view, FrameLayout.LayoutParams(-1, -1))
                cursor.bringToFront()
            }
            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null
                customCb?.onCustomViewHidden()
                customCb = null
            }
        }
        web.loadUrl(HOME)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    private fun click() {
        val target: View = customView ?: web
        val t = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, cursor.cx, cursor.cy, 0)
        target.dispatchTouchEvent(down); down.recycle()
        target.postDelayed({
            val t2 = SystemClock.uptimeMillis()
            val up = MotionEvent.obtain(t2, t2, MotionEvent.ACTION_UP, cursor.cx, cursor.cy, 0)
            target.dispatchTouchEvent(up); up.recycle()
        }, 60)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val k = e.keyCode
        // Toggle cursor: yellow button, Menu, or Subtitle
        if (k == KeyEvent.KEYCODE_PROG_YELLOW || k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_CAPTIONS) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
                cursorOn = !cursorOn
                cursor.visibility = if (cursorOn) View.VISIBLE else View.INVISIBLE
            }
            return true
        }
        if (!cursorOn) return super.dispatchKeyEvent(e)

        val step = (10 + minOf(e.repeatCount, 15) * 2) * resources.displayMetrics.density
        when (k) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (e.action == KeyEvent.ACTION_DOWN) {
                    val w = root.width.toFloat(); val h = root.height.toFloat()
                    when (k) {
                        KeyEvent.KEYCODE_DPAD_UP -> cursor.cy -= step
                        KeyEvent.KEYCODE_DPAD_DOWN -> cursor.cy += step
                        KeyEvent.KEYCODE_DPAD_LEFT -> cursor.cx -= step
                        else -> cursor.cx += step
                    }
                    cursor.cx = cursor.cx.coerceIn(0f, w - 2f)
                    cursor.cy = cursor.cy.coerceIn(0f, h - 2f)
                    // Cursor pushed against the top/bottom edge scrolls the page
                    if (cursor.cy <= 2f && k == KeyEvent.KEYCODE_DPAD_UP) web.scrollBy(0, (-step * 3).toInt())
                    if (cursor.cy >= h - 4f && k == KeyEvent.KEYCODE_DPAD_DOWN) web.scrollBy(0, (step * 3).toInt())
                    cursor.invalidate()
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) click()
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
