package app.seedtv

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.os.SystemClock
import android.text.InputType
import android.view.*
import android.webkit.*
import android.widget.*
import java.io.ByteArrayInputStream

// ---------------- EDIT THESE ----------------
private const val DEFAULT_SITE = "https://seedmivo.st"   // pre-loaded; can be deleted from the menu

// STRICT = false: block only the ad hosts below, allow other sub-resources (video players etc.).
// STRICT = true : sub-resources may load ONLY from the current site + ALLOWED_EXTRA (safest, but
//                 you must add the video player's host to ALLOWED_EXTRA or playback will break).
private const val STRICT = false
private val ALLOWED_EXTRA = listOf("image.tmdb.org")

private val BLOCKED = listOf(
    "doubleclick.net", "googlesyndication.com", "adservice.google.com", "popads.net",
    "popcash.net", "propellerads.com", "onclickads.net", "adsterra.com", "exoclick.com",
    "juicyads.com", "trafficjunky.com", "adnxs.com", "taboola.com", "outbrain.com", "histats.com",
    "adcash.com", "clickadu.com", "hilltopads.net", "mgid.com", "revcontent.com", "zedo.com",
    "yllix.com", "pubmatic.com", "rubiconproject.com", "openx.net", "criteo.com",
    "amazon-adsystem.com", "googletagservices.com", "admaven.com", "a-ads.com", "monetag.com"
)
// --------------------------------------------

private const val PREFS = "souravtv"
private const val KEY_SITES = "sites"   // newline-separated base URLs
private const val KEY_LAST = "last"

// Runs inside every page: no popups, no off-site links/forms, hides ad elements and ad overlays.
// window.__stvHosts (allowed hosts) and window.__stvDl (downloads switch) are set before it runs.
private const val CLEAN_JS = """
(function(){
  if (window.__stv) return; window.__stv = 1;
  window.open = function(){ return null; };
  var AD = /^(ad|ads|adv|advert|advertisement|adsbygoogle|ad-banner|banner-ad|ad-slot|ad-container|ad-wrapper|sponsor|sponsored|popunder|popup-ad|pop-ad)${'$'}/i;
  var SRC = /(^|[\/.\-_])(ads?|adserver|banner|popunder|sponsor)([\/.\-_?]|${'$'})/i;
  function host(u){ try { return new URL(u, location.href).hostname; } catch(e){ return ''; } }
  function okHost(h){
    var L = window.__stvHosts || []; h = (h || '').toLowerCase();
    for (var i=0;i<L.length;i++){ if (h === L[i] || h.slice(-(L[i].length+1)) === '.' + L[i]) return true; }
    return false;
  }
  function ext(u){ var h = host(u); return !!h && !okHost(h); }
  function blockExt(u){ return ext(u) && !window.__stvDl; }
  function hide(el){ el.style.setProperty('display','none','important'); }

  var ac = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){ if (this.href && blockExt(this.href)) return; return ac.apply(this, arguments); };
  var fs = HTMLFormElement.prototype.submit;
  HTMLFormElement.prototype.submit = function(){ if (this.action && ext(this.action)) return; return fs.apply(this, arguments); };
  document.addEventListener('submit', function(e){
    if (e.target && e.target.action && ext(e.target.action)) { e.preventDefault(); e.stopPropagation(); }
  }, true);
  document.addEventListener('click', function(e){
    var a = e.target && e.target.closest ? e.target.closest('a') : null;
    if (!a || !a.href || /^javascript:/i.test(a.href)) return;
    if (!/^https:/i.test(a.href) || blockExt(a.href)) { e.preventDefault(); e.stopPropagation(); return; }
    if (a.target === '_blank') a.target = '_self';
  }, true);

  function sweep(){
    var all = document.querySelectorAll('div,section,aside,ins,iframe,a,img');
    for (var i=0;i<all.length;i++){
      var el = all[i], bad = false;
      var cn = (typeof el.className === 'string') ? el.className : '';
      var toks = (cn + ' ' + (el.id||'')).split(/\s+/);
      for (var t=0;t<toks.length;t++){ if (toks[t] && AD.test(toks[t])) { bad = true; break; } }
      if (!bad && el.tagName === 'IFRAME' && el.src && ext(el.src) && SRC.test(el.src)) bad = true;
      if (!bad && (el.tagName === 'DIV' || el.tagName === 'IFRAME')) {
        var cs = getComputedStyle(el);
        if (cs.position === 'fixed' && parseInt(cs.zIndex||'0',10) >= 1000) {
          var r = el.getBoundingClientRect();
          var big = r.width*r.height > innerWidth*innerHeight*0.25;
          var off;
          if (el.tagName === 'IFRAME') off = ext(el.src);
          else {
            var as = el.querySelectorAll('a[href^="http"]');
            off = !!el.querySelector('iframe') || Array.prototype.some.call(as, function(x){ return ext(x.href); });
          }
          if (big && off && !el.querySelector('video')) bad = true;
        }
      }
      if (bad) hide(el);
    }
  }
  var pending = false;
  new MutationObserver(function(){
    if (pending) return; pending = true;
    setTimeout(function(){ pending = false; sweep(); }, 400);
  }).observe(document.documentElement, {childList:true, subtree:true});
  sweep();
})();
"""

private fun hostIn(host: String?, list: List<String>): Boolean {
    val h = host?.lowercase() ?: return false
    return list.any { val l = it.lowercase(); h == l || h.endsWith(".$l") }
}

private fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

class CursorView(c: Context) : View(c) {
    var cx = 0f
    var cy = 0f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 4f
    }
    override fun onDraw(canvas: Canvas) {
        val p = Path().apply {
            moveTo(cx, cy); lineTo(cx, cy + 42f); lineTo(cx + 12f, cy + 32f)
            lineTo(cx + 22f, cy + 52f); lineTo(cx + 30f, cy + 48f)
            lineTo(cx + 20f, cy + 29f); lineTo(cx + 34f, cy + 28f); close()
        }
        canvas.drawPath(p, fill)
        canvas.drawPath(p, edge)
    }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var cursor: CursorView
    private lateinit var root: FrameLayout
    private lateinit var prefs: SharedPreferences
    private val sites = mutableListOf<String>()
    private var current: String? = null
    private var currentHost: String? = null
    private var downloadsOn = false              // always OFF when the app starts
    private var cursorOn = true
    private var menu: View? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WebView.setWebContentsDebuggingEnabled(false)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val raw = prefs.getString(KEY_SITES, null)
        sites.addAll(if (raw == null) listOf(DEFAULT_SITE) else raw.split("\n").filter { it.isNotBlank() })

        root = FrameLayout(this)
        web = WebView(this)
        cursor = CursorView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(cursor, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        root.post { cursor.cx = root.width / 2f; cursor.cy = root.height / 2f; cursor.invalidate() }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            allowContentAccess = false
            setGeolocationEnabled(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        // Downloads are refused unless the menu switch is ON
        web.setDownloadListener { url, ua, cd, mime, _ ->
            if (!downloadsOn) {
                toast("Download blocked. Menu > Allow downloads to enable.")
                return@setDownloadListener
            }
            startDownload(url, ua, cd, mime)
        }

        web.webViewClient = object : WebViewClient() {
            // Abort every redirect / link that leaves the current site, and every non-https scheme.
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url; val s = u.scheme
                if (r.isForMainFrame) {
                    if (s != "https") return true
                    if (hostIn(u.host, listOfNotNull(currentHost))) return false
                    // Never leave the site. With downloads ON, a link you click that points
                    // elsewhere is sent to the download manager instead of being opened.
                    if (downloadsOn && r.hasGesture()) startDownload(u.toString(), web.settings.userAgentString, null, null)
                    return true
                }
                return s != "https" && s != "about" && s != "data" && s != "blob"
            }

            override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) {
                v.evaluateJavascript(cleanJs(), null)
            }
            override fun onPageFinished(v: WebView, url: String?) {
                v.evaluateJavascript(cleanJs(), null)
            }

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val s = r.url.scheme
                val h = r.url.host
                if (s == "http") return empty()
                if (s != "https" && s != "data" && s != "blob" && s != "about") return empty()
                if (hostIn(h, BLOCKED)) return empty()
                if (STRICT && s == "https" && !hostIn(h, listOfNotNull(currentHost) + ALLOWED_EXTRA)) return empty()
                return null
            }

            override fun onReceivedSslError(v: WebView, h: SslErrorHandler, e: android.net.http.SslError) {
                h.cancel()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(v: WebView, d: Boolean, u: Boolean, m: Message?) = false
            override fun onJsAlert(v: WebView, url: String?, msg: String?, r: JsResult): Boolean { r.cancel(); return true }
            override fun onJsConfirm(v: WebView, url: String?, msg: String?, r: JsResult): Boolean { r.cancel(); return true }
            override fun onJsPrompt(v: WebView, url: String?, msg: String?, def: String?, r: JsPromptResult): Boolean { r.cancel(); return true }
            override fun onJsBeforeUnload(v: WebView, url: String?, msg: String?, r: JsResult): Boolean { r.confirm(); return true }
            override fun onPermissionRequest(r: PermissionRequest) {
                val ok = r.resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }.toTypedArray()
                if (ok.isEmpty()) r.deny() else r.grant(ok)
            }
            override fun onGeolocationPermissionsShowPrompt(o: String, cb: GeolocationPermissions.Callback) {
                cb.invoke(o, false, false)
            }
            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                customView = view; customCb = cb
                root.addView(view, FrameLayout.LayoutParams(-1, -1))
                cursor.bringToFront()
            }
            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null
                customCb?.onCustomViewHidden()
                customCb = null
            }
        }

        val last = prefs.getString(KEY_LAST, null)
        val start = if (last != null && last in sites) last else sites.firstOrNull()
        if (start != null) openSite(start) else showEmpty()
    }

    // ---------- sites ----------
    private fun cleanJs(): String {
        val hosts = listOfNotNull(currentHost?.lowercase())
            .filter { it.matches(Regex("[a-z0-9.-]+")) }
            .joinToString(",") { "\"$it\"" }
        return "window.__stvHosts=[$hosts];window.__stvDl=$downloadsOn;" + CLEAN_JS
    }

    private fun saveSites() { prefs.edit().putString(KEY_SITES, sites.joinToString("\n")).apply() }

    private fun openSite(url: String) {
        current = url
        currentHost = Uri.parse(url).host
        prefs.edit().putString(KEY_LAST, url).apply()
        web.loadUrl(url)
    }

    private fun showEmpty() {
        current = null; currentHost = null
        web.loadDataWithBaseURL(null,
            "<html><body style='background:#0a0b14;color:#ddd;font:28px sans-serif;padding:60px'>" +
            "No sites yet.<br><br>Press Menu (or the blue button) to add one.</body></html>",
            "text/html", "utf-8", null)
    }

    private fun normalize(raw: String): String? {
        var t = raw.trim()
        if (t.isEmpty() || t.contains(' ')) return null
        if (!t.contains("://")) t = "https://$t"
        if (!t.startsWith("https://", ignoreCase = true)) return null
        val h = Uri.parse(t).host ?: return null
        if (!h.contains('.') || !h.matches(Regex("[A-Za-z0-9.-]+"))) return null
        val u = Uri.parse(t)
        return "https://" + h.lowercase() + (if (u.port != -1) ":" + u.port else "")
    }

    private fun addSite(raw: String) {
        val n = normalize(raw)
        if (n == null) { toast("Enter a valid https:// address"); return }
        if (n in sites) { toast("Already added"); return }
        sites.add(n); saveSites(); toast("Added")
        if (current == null) openSite(n)
        rebuildMenu()
    }

    private fun promptAddSite() {
        val input = EditText(this).apply {
            hint = "https://example.com"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        AlertDialog.Builder(this).setTitle("Add site").setView(input)
            .setPositiveButton("Add") { _, _ -> addSite(input.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun confirmRemove(url: String) {
        AlertDialog.Builder(this).setTitle("Remove site?").setMessage(url)
            .setPositiveButton("Remove") { _, _ ->
                sites.remove(url); saveSites()
                if (url == current) sites.firstOrNull()?.let { openSite(it) } ?: showEmpty()
                rebuildMenu()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- downloads ----------
    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?) {
        if (!url.startsWith("https://")) { toast("Blocked: download is not https"); return }
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            if (!mime.isNullOrEmpty()) req.setMimeType(mime)
            if (!ua.isNullOrEmpty()) req.addRequestHeader("User-Agent", ua)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            if (Build.VERSION.SDK_INT >= 29) req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            else req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Downloading $name")
        } catch (e: Exception) {
            toast("Could not start download")
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---------- menu ----------
    private fun <T : TextView> styled(v: T): T {
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), ColorDrawable(Color.rgb(124, 58, 237)))
        sl.addState(intArrayOf(), ColorDrawable(Color.rgb(36, 40, 60)))
        v.background = sl
        v.setTextColor(Color.WHITE)
        v.isFocusable = true
        v.textSize = 18f
        return v
    }

    private fun btn(text: String, onClick: () -> Unit): Button =
        styled(Button(this)).also { it.text = text; it.isAllCaps = false; it.setOnClickListener { onClick() } }

    private fun showMenu() {
        if (menu != null) return
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun lp(w: Int, weight: Float = 0f) =
            LinearLayout.LayoutParams(w, LinearLayout.LayoutParams.WRAP_CONTENT, weight).apply { setMargins(0, px(4), 0, px(4)) }
        fun label(t: String, size: Float, color: Int) = TextView(this).apply { text = t; textSize = size; setTextColor(color) }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(16), px(20), px(16))
        }
        var first: View? = null
        col.addView(label("SouravTV", 24f, Color.WHITE), lp(-1))
        col.addView(label("Sites", 14f, Color.LTGRAY), lp(-1))

        for (url in sites.toList()) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val name = (if (url == current) "▶ " else "") + (Uri.parse(url).host ?: url)
            val open = btn(name) { openSite(url); hideMenu() }
            val del = btn("✕") { confirmRemove(url) }
            row.addView(open, lp(0, 1f))
            row.addView(del, lp(px(64)))
            col.addView(row, LinearLayout.LayoutParams(-1, -2))
            if (first == null) first = open
        }
        val add = btn("+  Add site") { promptAddSite() }
        col.addView(add, lp(-1))
        if (first == null) first = add

        col.addView(label("Downloads", 14f, Color.LTGRAY), lp(-1))
        val sw = styled(Switch(this)).apply {
            text = "Allow downloads"
            isChecked = downloadsOn
            setPadding(px(12), px(10), px(12), px(10))
            setOnCheckedChangeListener { _, on ->
                downloadsOn = on
                web.evaluateJavascript("window.__stvDl=$on", null)
                toast(if (on) "Downloads ON. Turn off when done." else "Downloads OFF")
            }
        }
        col.addView(sw, lp(-1))
        col.addView(label("OFF every time the app starts. While ON, a link to another site is downloaded, never opened.", 13f, Color.GRAY), lp(-1))
        col.addView(btn("Close menu") { hideMenu() }, lp(-1))

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.argb(245, 12, 14, 26))
            addView(col)
        }
        root.addView(scroll, FrameLayout.LayoutParams(px(460), -1, Gravity.END))
        menu = scroll
        cursor.visibility = View.INVISIBLE
        first?.requestFocus()
    }

    private fun hideMenu() {
        menu?.let { root.removeView(it) }
        menu = null
        cursor.visibility = if (cursorOn) View.VISIBLE else View.INVISIBLE
        web.requestFocus()
    }

    private fun rebuildMenu() { hideMenu(); showMenu() }

    // ---------- input ----------
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    private fun click() {
        val target: View = customView ?: web
        val t = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, cursor.cx, cursor.cy, 0)
        target.dispatchTouchEvent(down); down.recycle()
        target.postDelayed({
            val t2 = SystemClock.uptimeMillis()
            val up = MotionEvent.obtain(t2, t2, MotionEvent.ACTION_UP, cursor.cx, cursor.cy, 0)
            target.dispatchTouchEvent(up); up.recycle()
        }, 60)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val k = e.keyCode
        // Open / close the menu: Menu key or Blue button
        if (k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_PROG_BLUE) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) { if (menu == null) showMenu() else hideMenu() }
            return true
        }
        // Toggle the cursor: Yellow button or Subtitle
        if (k == KeyEvent.KEYCODE_PROG_YELLOW || k == KeyEvent.KEYCODE_CAPTIONS) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 && menu == null) {
                cursorOn = !cursorOn
                cursor.visibility = if (cursorOn) View.VISIBLE else View.INVISIBLE
            }
            return true
        }
        if (menu != null || !cursorOn) return super.dispatchKeyEvent(e)

        val step = (10 + minOf(e.repeatCount, 15) * 2) * resources.displayMetrics.density
        when (k) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (e.action == KeyEvent.ACTION_DOWN) {
                    val w = root.width.toFloat(); val h = root.height.toFloat()
                    when (k) {
                        KeyEvent.KEYCODE_DPAD_UP -> cursor.cy -= step
                        KeyEvent.KEYCODE_DPAD_DOWN -> cursor.cy += step
                        KeyEvent.KEYCODE_DPAD_LEFT -> cursor.cx -= step
                        else -> cursor.cx += step
                    }
                    cursor.cx = cursor.cx.coerceIn(0f, w - 2f)
                    cursor.cy = cursor.cy.coerceIn(0f, h - 2f)
                    if (cursor.cy <= 2f && k == KeyEvent.KEYCODE_DPAD_UP) web.scrollBy(0, (-step * 3).toInt())
                    if (cursor.cy >= h - 4f && k == KeyEvent.KEYCODE_DPAD_DOWN) web.scrollBy(0, (step * 3).toInt())
                    cursor.invalidate()
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) click()
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            menu != null -> hideMenu()
            customView != null -> web.webChromeClient?.onHideCustomView()
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
